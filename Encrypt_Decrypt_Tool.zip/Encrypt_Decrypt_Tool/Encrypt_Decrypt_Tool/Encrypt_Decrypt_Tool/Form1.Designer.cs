﻿namespace Encrypt_Decrypt_Tool
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtdecrypt = new System.Windows.Forms.TextBox();
            this.txtencrypt = new System.Windows.Forms.TextBox();
            this.txtvalue = new System.Windows.Forms.TextBox();
            this.btnencrypt = new System.Windows.Forms.Button();
            this.btndecrypt = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btncopyenc = new System.Windows.Forms.Button();
            this.btncopydec = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Value: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Encrypted Text: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Decrypted Text: ";
            // 
            // txtdecrypt
            // 
            this.txtdecrypt.Location = new System.Drawing.Point(105, 111);
            this.txtdecrypt.Name = "txtdecrypt";
            this.txtdecrypt.ReadOnly = true;
            this.txtdecrypt.Size = new System.Drawing.Size(292, 20);
            this.txtdecrypt.TabIndex = 3;
            // 
            // txtencrypt
            // 
            this.txtencrypt.Location = new System.Drawing.Point(105, 68);
            this.txtencrypt.Name = "txtencrypt";
            this.txtencrypt.ReadOnly = true;
            this.txtencrypt.Size = new System.Drawing.Size(292, 20);
            this.txtencrypt.TabIndex = 2;
            // 
            // txtvalue
            // 
            this.txtvalue.Location = new System.Drawing.Point(105, 27);
            this.txtvalue.Name = "txtvalue";
            this.txtvalue.Size = new System.Drawing.Size(292, 20);
            this.txtvalue.TabIndex = 1;
            this.txtvalue.TextChanged += new System.EventHandler(this.txtvalue_TextChanged);
            // 
            // btnencrypt
            // 
            this.btnencrypt.Location = new System.Drawing.Point(40, 158);
            this.btnencrypt.Name = "btnencrypt";
            this.btnencrypt.Size = new System.Drawing.Size(75, 23);
            this.btnencrypt.TabIndex = 5;
            this.btnencrypt.Text = "Encrypt";
            this.btnencrypt.UseVisualStyleBackColor = true;
            this.btnencrypt.Click += new System.EventHandler(this.btnencrypt_Click);
            // 
            // btndecrypt
            // 
            this.btndecrypt.Location = new System.Drawing.Point(192, 158);
            this.btndecrypt.Name = "btndecrypt";
            this.btndecrypt.Size = new System.Drawing.Size(75, 23);
            this.btndecrypt.TabIndex = 6;
            this.btndecrypt.Text = "Decrypt";
            this.btndecrypt.UseVisualStyleBackColor = true;
            this.btndecrypt.Click += new System.EventHandler(this.btndecrypt_Click);
            // 
            // btnclose
            // 
            this.btnclose.Location = new System.Drawing.Point(336, 158);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(75, 23);
            this.btnclose.TabIndex = 7;
            this.btnclose.Text = "Close";
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "copy_emY_icon.ico");
            // 
            // btncopyenc
            // 
            this.btncopyenc.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btncopyenc.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btncopyenc.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btncopyenc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncopyenc.ImageIndex = 0;
            this.btncopyenc.ImageList = this.imageList1;
            this.btncopyenc.Location = new System.Drawing.Point(403, 67);
            this.btncopyenc.Name = "btncopyenc";
            this.btncopyenc.Size = new System.Drawing.Size(30, 21);
            this.btncopyenc.TabIndex = 8;
            this.toolTip1.SetToolTip(this.btncopyenc, "Copy to Clipboard");
            this.btncopyenc.UseVisualStyleBackColor = true;
            this.btncopyenc.Click += new System.EventHandler(this.btncopyenc_Click);
            // 
            // btncopydec
            // 
            this.btncopydec.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btncopydec.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btncopydec.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btncopydec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncopydec.ImageIndex = 0;
            this.btncopydec.ImageList = this.imageList1;
            this.btncopydec.Location = new System.Drawing.Point(403, 111);
            this.btncopydec.Name = "btncopydec";
            this.btncopydec.Size = new System.Drawing.Size(30, 21);
            this.btncopydec.TabIndex = 9;
            this.toolTip1.SetToolTip(this.btncopydec, "Copy to Clipboard");
            this.btncopydec.UseVisualStyleBackColor = true;
            this.btncopydec.Click += new System.EventHandler(this.btncopydec_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 196);
            this.Controls.Add(this.btncopydec);
            this.Controls.Add(this.btncopyenc);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.btndecrypt);
            this.Controls.Add(this.btnencrypt);
            this.Controls.Add(this.txtvalue);
            this.Controls.Add(this.txtencrypt);
            this.Controls.Add(this.txtdecrypt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AXAXL Encrypt / Decrypt Tool";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtdecrypt;
        private System.Windows.Forms.TextBox txtencrypt;
        private System.Windows.Forms.TextBox txtvalue;
        private System.Windows.Forms.Button btnencrypt;
        private System.Windows.Forms.Button btndecrypt;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button btncopyenc;
        private System.Windows.Forms.Button btncopydec;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}


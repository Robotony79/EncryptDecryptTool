﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;

namespace Encrypt_Decrypt_Tool
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      
        public bool IsAuthenticated(string username, string pwd)
        {

            string user = username;
            string pss = pwd;
            DirectoryEntry entry = new DirectoryEntry("LDAP://r02.xlgs.local", user, pss);
            try
            {
                object obj = entry.NativeObject;
                DirectorySearcher search = new DirectorySearcher(entry);
                search.Filter = "(SAMAccountName=" + username + ")";
                search.PropertiesToLoad.Add("cn");
                SearchResult result = search.FindOne();
                if ((result == null))
                {
                    return false;
                }
                else
                {
                    if (IsInGroup(username, pwd))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }

                
            }
            catch (Exception ex)
            {                
                MessageBox.Show(ex.Message.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            
        }

        public bool IsInGroup(string usr,string pass)
        {
            PrincipalContext ctx = new PrincipalContext(ContextType.Domain, "R02");
            UserPrincipal user = UserPrincipal.FindByIdentity(ctx, usr);
            GroupPrincipal group = GroupPrincipal.FindByIdentity(ctx, "CAS-DS-DBA-Team-Admins");

            if (user != null)
            {                
                if (user.IsMemberOf(group))
                {
                    return true;
                }
            }

            return false;
        }


        private void btnlogin_Click(object sender, EventArgs e)
        {
            if(!(String.IsNullOrEmpty(txtuser.Text) || (String.IsNullOrEmpty(txtuser.Text))))
            {
                if (!(String.IsNullOrEmpty(txtpass.Text) || (String.IsNullOrEmpty(txtpass.Text))))
                {
                    if (IsAuthenticated(txtuser.Text, txtpass.Text))
                    {
                        this.Hide();
                        Form1 form = new Form1();
                        form.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Permission is not granted for the tool", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Password cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtpass.Focus();
                }
            }
            else
            {
                MessageBox.Show("Username cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtuser.Focus();
            }

        }

        private void txtpass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnlogin_Click(this, new EventArgs());
            }
        }

        private void txtuser_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnlogin_Click(this, new EventArgs());
            }
        }


    }
}

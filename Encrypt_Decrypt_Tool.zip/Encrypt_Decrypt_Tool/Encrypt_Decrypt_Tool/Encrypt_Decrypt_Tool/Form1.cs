﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace Encrypt_Decrypt_Tool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
                
        string EncryptionKey = "C4sDb4t34mRul3$$#%&";

        public string Encrypt(string value)
        {
            try
            {

                byte[] clearBytes = Encoding.Unicode.GetBytes(value);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(clearBytes, 0, clearBytes.Length);
                            cs.Close();
                        }
                        value = Convert.ToBase64String(ms.ToArray());
                    }
                }
                return value;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
                return null;
            }
        }
        
        public string Decrypt(string value)
        {
            try
            {
                value = value.Replace(" ", "+");
                byte[] cipherBytes = Convert.FromBase64String(value);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(cipherBytes, 0, cipherBytes.Length);
                            cs.Close();
                        }
                        value = Encoding.Unicode.GetString(ms.ToArray());
                    }
                }
                return value;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
                return null;
            }
        }

        private void btnencrypt_Click(object sender, EventArgs e)
        {
            if(!(String.IsNullOrEmpty(txtvalue.Text) ||  String.IsNullOrWhiteSpace(txtvalue.Text)))
            {
                txtdecrypt.Text = "";
                txtencrypt.Text=Encrypt(txtvalue.Text);
                txtencrypt.Focus();
                txtencrypt.Select();
            } 
            else
            {
                MessageBox.Show("Value cannot be empty","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void btndecrypt_Click(object sender, EventArgs e)
        {
            if(!(String.IsNullOrEmpty(txtvalue.Text) ||  String.IsNullOrWhiteSpace(txtvalue.Text)))
            {
                txtencrypt.Text = "";
                txtdecrypt.Text = Decrypt(txtvalue.Text);
                txtdecrypt.Focus();
                txtdecrypt.Select();
            }
            else
            {
                MessageBox.Show("Value cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btncopyenc_Click(object sender, EventArgs e)
        {
            if (!(String.IsNullOrEmpty(txtencrypt.Text) || String.IsNullOrWhiteSpace(txtencrypt.Text)))
            {
                Clipboard.SetText(txtencrypt.Text);
            }
            else
            {
                MessageBox.Show("Encryption has not been performed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btncopydec_Click(object sender, EventArgs e)
        {
            if (!(String.IsNullOrEmpty(txtdecrypt.Text) || String.IsNullOrWhiteSpace(txtdecrypt.Text)))
            {
                Clipboard.SetText(txtdecrypt.Text);
            }
            else
            {
                MessageBox.Show("Decryption has not been performed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtvalue_TextChanged(object sender, EventArgs e)
        {
            txtencrypt.Text = "";
            txtdecrypt.Text = "";
        }

    }
}
